public class Main {
    public static void main(String[] args) {
        new GameIO(new Game(), 64, 0.9);
    }
}