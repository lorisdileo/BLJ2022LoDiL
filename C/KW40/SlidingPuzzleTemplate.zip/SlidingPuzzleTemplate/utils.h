#ifndef UTILS_H
#define UTILS_H
void printField(int size, int field[size][size]);
void swapValues(int *num1, int *num2);
#endif

